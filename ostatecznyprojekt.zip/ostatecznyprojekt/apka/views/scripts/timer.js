function Odliczanie()
{
    var data = new Date();
    var godz = data.getHours();
    var min = data.getMinutes();
    var sek = data.getSeconds();
//  var rok = data.getFullYear();
//  var msc = data.getMonth();
//  var dz = data.getDay();

/*Dopisanie zera przy jedncyfrowych liczbach*/
    godz = (godz < 10) ? "0" + godz : godz;
    min = (min < 10) ? "0" + min : min;
    sek = (sek < 10) ? "0" + sek : sek;   
/*Ustawienie całości jako jednej zmiennej*/
    var czas = godz + ":" + min + ":" + sek;

    document.getElementById("ClockDisplay").innerText = czas;
    document.getElementById("ClockDisplay").textContent = czas;
    
    setTimeout("Odliczanie()",1000);
}