const express = require('express');
const app = express();
const multer = require('multer');
const path = require('path');
const http = require('http').Server(app);
const io = require('socket.io')(http);
const uuid = require('uuid').v4;
const port = process.env.PORT || 3000;
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads')
    },
    filename: (req, file, cb) => {
        const { originalname } = file;
        // or 
        // uuid, or fieldname
        cb(null, originalname);
    }
})

const upload = multer({ storage }); // or simply { dest: 'uploads/' }
app.use(express.static('./views'))

app.post('/upload', upload.array('avatar'), (req, res) => {
    return res.json({ status: 'OK', uploaded: req.files.length });
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/index.html');
  });
  
  io.on('connection', (socket) => {
    socket.on('chat message', msg => {
      io.emit('chat message', msg);
    });
  });

  http.listen(port, () => {
    console.log(`Socket.IO server running at http://localhost:${port}/`);
  });









