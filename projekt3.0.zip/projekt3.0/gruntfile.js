module.expert = function (grunt) 
{
grunt.initConfig({
pkg: grunt.file.readJSON('package.json')
 });
}
