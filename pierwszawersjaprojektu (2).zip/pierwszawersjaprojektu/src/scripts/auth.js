//https://firebase.google.com/docs/web/setup#available-libraries


// Your web app's Firebase configuration
var firebaseConfig = {
    apiKey: "AIzaSyDUPgdbwZQ8lvjf-cJhJP1i6twYs-jLUfQ",
    authDomain: "confapp-e1637.firebaseapp.com",
    projectId: "confapp-e1637",
    storageBucket: "confapp-e1637.appspot.com",
    messagingSenderId: "825755715639",
    appId: "1:825755715639:web:f87da9927fd41248aad7b2"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
var signUpButton = document.getElementById('sign-up');
var signInButton = document.getElementById('sign-in');
var signOutButton = document.getElementById('sing-out');


function signUp() {
    let email = document.getElementById('email');
    let pass = document.getElementById('password');
    const promise = auth.createUserWithEmailAndPassword(email.value, pass.value);
    promise.catch(e => alert(e));
    alert("Rejstracja udana");

}

function signIn() {
    let email = document.getElementById('email');
    let pass = document.getElementById('password');
    const promise = auth.signInWithEmailAndPassword(email.value, pass.value);
    let e = [];
    promise.catch(e => alert(e));
    if (!e) {
        alert("Cześć, " + email.value);
        /*$('#sign-up').fadeOut();
        signUpButton.fadeOut();*/
    } else {
		alert("Nie udało się zalogować");
	}

}

function signOut() {
    auth.signOut();
    alert('Wylogowałeś się');

}

auth.onAuthStateChanged(function (user) {
    if (user) {
        var email = user.email;
       sessionStorage.setItem('email', email);

    } else {
        sessionStorage.removeItem('email');
    }
})

/*$(document).ready(function(){
    $('#sign-up').fadeOut();
    signUpButton.fadeOut();
});*/

