const express = require('express')
const port = process.env.PORT || 3000

const app = express()
app.set('view engine', 'hbs')

app.get('/', (req, res) => {

    res.render('index')
    pageTitle: 'Aplikacja konferencyjna'
    pageBody:'Helloooooo'
})
app.get('/quiz', (req, res) => {

    res.render('quiz')
    pageTitle: 'Quiz'})
app.listen(port)