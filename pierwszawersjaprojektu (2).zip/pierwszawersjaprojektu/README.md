# Dolby Interactivity APIs Browser SDK Getting Started app

This is the sample app from the browser app used in the
[Getting Started](https://dolby.io/developers/interactivity-apis/client-sdk/getting-started/create-a-basic-audio-conference-application) article. 

You can find additional reference documentation here:
- [JavaScript Reference](https://dolby.io/developers/interactivity-apis/client-sdk/reference-javascript/voxeetsdk)


## Running

See [this page](https://dolby.io/developers/interactivity-apis/client-sdk/getting-started/create-a-basic-audio-conference-application#step-6-run-your-application)
for instructions on how to run the app.
