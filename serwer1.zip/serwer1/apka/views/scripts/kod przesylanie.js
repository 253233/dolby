const file_path = "C:/Users/Fabian Kołodziejek/Desktop/test/MyAudio.mp4" //ścieżka docelowa wysyłanego pliku
const api_key = "bSHvzKQAPZl21zHj2QCQfF4HbEaQBaKC" //Media processing api https://dolby.io/dashboard/applications/365766/keys 
const my_audio = "dlb://in/MyAudio.mp4" //Skrócony adres dlb którym należy się posługiwać 
const my_audio_out =  "dlb://out/MyAudio.mp4" //Skrócony adres dlb do pobrania pliku
const file_out_put = "C:/Users/Fabian Kołodziejek/Desktop/test/output/MyAudio.mp4" //ścieżka docelowa zapisu pliku
var job_id = ""; //Mój job_id, generowany po użyciu funkcji Enhance


//Przesłanie pliku do chmury Dolby, po przesłaniu można posługiwać się stałą my_audio
function audio_send()
{
const fs = require("fs")
const axios = require("axios").default


// Deklaracja adresu dlb

const config = {
  method: "post",
  url: "https://api.dolby.com/media/input",
  headers: {
    "x-api-key": api_key,
    "Content-Type": "application/json",
    Accept: "application/json",
  },
  data: {
    url: my_audio,
    
  },
}

axios(config)
  .then(function(response) {
    // Upload your media to the pre-signed url response

    const upload_config = {
      method: "put",
      url: response.data.url,
      data: fs.createReadStream(file_path),
      headers: {
        "Content-Type": "application/octet-stream",
        "Content-Length": fs.statSync(file_path).size,
      },
    }
    axios(upload_config)
      .then(function() {
        console.log("Status pliku: File uploaded")
      })
      .catch(function(error) {
        console.log(error)
      })
  })
  .catch(function(error) {
    console.log(error)
  })
}

//Zapytanie o ulepszenie pliku, po zakończeniu ulepszenia pliku można posługiwać się stałą my_audio_out, funkcja drukuje job_id
function audio_enhance(){
  const axios = require("axios").default

const config = {
  method: "post",
  url: "https://api.dolby.com/media/enhance",
  headers: {
    "x-api-key": api_key,
    "Content-Type": "application/json",
    Accept: "application/json",
  },
  data: {
    input: my_audio,
    output: my_audio_out,
  },
}

axios(config)
  .then(function(response) {
    console.log(response.data.job_id)
  })
  .catch(function(error) {
    console.log(error)
  })
}
//Sprawdzanie statusu ulepszania pliku, należy przed użyciem wprowadzić wcześniej wygenerowany job_id
function check_status_enhance(job_id=""){
  const axios = require("axios").default

  const config = {
    method: "get",
    url: "https://api.dolby.com/media/enhance",
    headers: {
      "x-api-key": api_key,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    params: {
      job_id: job_id,
    },
  }}